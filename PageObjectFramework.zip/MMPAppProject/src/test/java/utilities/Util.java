package utilities;

public class Util {
	public static final String PATIENT_UNAME="begum";
	public static final String PATIENT_PASSWORD="1Loveusa";
	public static final String BASEPAGE_TITLE="NAMTG";
	public static final String LOGINPAGE_TITLE="Login";
	public static final String LOGIN_HEADER="Patient Login";
	public static final String PATIENTHOMEPAGE_TITLE="home";
	public static final String SCHEDULEAPP_TITLE="Shedule Appointment";
	public static final String PROVIDERPAGE_TITLE="Providers";
	public static final String CALENDARPAGE_TITLE="appointment";
	public static final String CALENDAR_STATUS="OK";
	public static final String SYMPTOMS_TITLE="appointment";
	public static final String DOCTOR="kalpana";
	public static final String APP_DAY="31";
	public static final String APP_TIME="12Pm";
	public static final String SYMPTOMS="Abdominal Pain";
}
