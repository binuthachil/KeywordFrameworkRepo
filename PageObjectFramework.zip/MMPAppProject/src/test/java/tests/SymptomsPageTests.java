package tests;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBaseSetup;
import pageobjects.BasePage;
import pageobjects.BookAppointmentFrame;
import pageobjects.PatientHomePage;
import pageobjects.ProvidersPage;
import pageobjects.ScheduleAppPage;
import pageobjects.SignInPage;
import pageobjects.SymptomsPage;
import utilities.Util;

public class SymptomsPageTests extends TestBaseSetup {
	private WebDriver driver;
	private BasePage basePage;
	private SignInPage signInPage;
	private PatientHomePage patientHomePage;
	private ScheduleAppPage scheduleAppPage;
	private ProvidersPage providersPage;
	private BookAppointmentFrame bookAppointmentFrame;
	private SymptomsPage symptomsPage;
	
		
		@BeforeClass
		public void setUp() {
			driver=getDriver();
		}
		
		
		@Test
		public void verifySymptomsPageTitle()
		{
			System.out.println("Schedule Appointment Page Tests");
			basePage = new BasePage(driver);
			signInPage = basePage.clickLoginBtn();
			patientHomePage=signInPage.signInFn(Util.PATIENT_UNAME, Util.PATIENT_PASSWORD);
			scheduleAppPage=patientHomePage.clkScheduleAppBtn();
			providersPage=scheduleAppPage.clkNewAppBtn();
			bookAppointmentFrame=providersPage.clickOnDoctor("jack");
			symptomsPage=bookAppointmentFrame.scheduleAppointment("30", "12Pm");
			patientHomePage=symptomsPage.submitSymptoms("Knee Pain");
			//Assert.assertTrue(symptomsPage.verifySymptomsPageTitle("symptoms"), "Page title doesn't match");
		}
}

