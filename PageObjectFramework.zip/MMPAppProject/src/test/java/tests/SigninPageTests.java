package tests;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBaseSetup;
import utilities.Util;

import pageobjects.BasePage;
import pageobjects.SignInPage;

public class SigninPageTests extends TestBaseSetup{
	private WebDriver driver;
	private SignInPage signInPage;
	private BasePage basePage;

	@BeforeClass
	public void setUp() {
		driver=getDriver();
	}
	@Test
	public void verifySigninPage()
	{
		System.out.println("Sign In Page Tests");
		basePage = new BasePage(driver);
		signInPage = basePage.clickLoginBtn();
		Assert.assertTrue(signInPage.verifySignInPageTitle("Login"), "Sign In page title doesn't match");
	}
	@Test(dependsOnMethods="verifySigninPage")
	public void verifyLoginHeaderCaption()
	{
		Assert.assertTrue(signInPage.verifySignInPageHeader("Patient Login"), "Login Header not matching");
	}

	@Test(dependsOnMethods="verifyLoginHeaderCaption")
	public void verifySignInFn() {

		Assert.assertTrue(signInPage.verifySignIn(Util.PATIENT_UNAME, Util.PATIENT_PASSWORD), "Wrong Login Credentials");
	}

}
