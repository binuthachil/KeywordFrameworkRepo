package tests;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBaseSetup;
import pageobjects.BasePage;
import pageobjects.BookAppointmentFrame;
import pageobjects.PatientHomePage;
import pageobjects.ProvidersPage;
import pageobjects.ScheduleAppPage;
import pageobjects.SignInPage;
import pageobjects.SymptomsPage;
import utilities.Util;

public class MMPTestCases extends TestBaseSetup {
	private WebDriver driver;
	private BasePage basePage;
	private SignInPage signInPage;
	private PatientHomePage patientHomePage;
	private ScheduleAppPage scheduleAppPage;
	private ProvidersPage providersPage;
	private BookAppointmentFrame bookAppointmentFrame;
	private SymptomsPage symptomsPage;
	Logger logger;

	@BeforeClass
	public void setUp() {
		driver = getDriver();
		logger=Logger.getLogger("MMPTestCases");
		PropertyConfigurator.configure("Log4j.properties");
	}

	// Home page Tests Page Title
	@Test
	public void verifyHomePage() {
		//System.out.println("Home page test...");
		logger.info("Verify Home Page Tests");          
		basePage = new BasePage(driver);
		Assert.assertTrue(basePage.verifyBasePageTitle(Util.BASEPAGE_TITLE), "Home page title doesn't match");
	}

	// Check Signin Page Title
	@Test(dependsOnMethods = "verifyHomePage")
	public void verifySigninPage() {
		System.out.println("Sign In Page Tests");
		logger.info("Sign In page Tests");          
		signInPage = basePage.clickLoginBtn();
		Assert.assertTrue(signInPage.verifySignInPageTitle(Util.LOGINPAGE_TITLE), "Sign In page title doesn't match");
	}

	// Check Signin Page Header
	@Test(dependsOnMethods = "verifySigninPage")
	public void verifyLoginHeaderCaption() {
		Assert.assertTrue(signInPage.verifySignInPageHeader(Util.LOGIN_HEADER), "Login Header not matching");
	}

	// Verify Login
	@Test(dependsOnMethods = "verifyLoginHeaderCaption")
	public void verifySignInFn() {

		// Assert.assertTrue(signInPage.verifySignIn(Util.PATIENTUNAME,
		// Util.PATIENTPASSWORD), "Wrong Login Credentials");
		patientHomePage = signInPage.signInFn(Util.PATIENT_UNAME, Util.PATIENT_PASSWORD);
	}

	// Check Patient Home Page Title
	@Test(dependsOnMethods = "verifySignInFn")
	public void verifyPatientHomePage() {
		Assert.assertTrue(patientHomePage.verifyHomePageTitle(Util.PATIENTHOMEPAGE_TITLE),
				"Home Page title doesn't match");
	}

	// Check Scedule Appointment Page Title
	@Test(dependsOnMethods = "verifyPatientHomePage")
	public void verifyScheduleAppPage() {
		System.out.println("Schedule Appointment Page Tests");
		scheduleAppPage = patientHomePage.clkScheduleAppBtn();
		Assert.assertTrue(scheduleAppPage.verifySchedulePageTitle(Util.SCHEDULEAPP_TITLE),
				"Home Page title doesn't match");
	}

	// Check Providers Page Title
	@Test(dependsOnMethods = "verifyScheduleAppPage")
	public void verifyProvidersPage() {
		System.out.println("Schedule Appointment Page Tests");
		providersPage = scheduleAppPage.clkNewAppBtn();
		Assert.assertTrue(providersPage.verifyProviderPageTitle(Util.PROVIDERPAGE_TITLE),
				"Providers Page title doesn't match");

	}

	// Check Calendar Page Title
	@Test(dependsOnMethods = "verifyProvidersPage")
	public void verifyCalendarFramePage() {
		System.out.println("Schedule Appointment Page Tests");
		bookAppointmentFrame = providersPage.clickOnDoctor(Util.DOCTOR);
		// Assert.assertTrue(bookAppointmentFrame.verifyDateFrameTitle(Util.CALENDARPAGE_TITLE),
		// "Frame title doesn't match");
	}

	// Check Calendar is available for te given time
	@Test(dependsOnMethods = "verifyCalendarFramePage")
	public void verifyCalendarAvailable() {
		String calendarStatus = bookAppointmentFrame.verifyTimeAvailable(Util.APP_DAY, Util.APP_TIME);
		Assert.assertEquals(calendarStatus, Util.CALENDAR_STATUS, "Time not Available");
	}

	// Check Symptoms Page Title
	@Test(dependsOnMethods = "verifyCalendarAvailable")
	public void verifySymptomsPageTitle() {
		System.out.println("Symptoms Page Tests");
		symptomsPage = bookAppointmentFrame.clickOnContinue();
		Assert.assertTrue(symptomsPage.verifySymptomsPageTitle(Util.SYMPTOMS_TITLE), "Page title doesn't match");
	}

	// Verify appointment done
	@Test(dependsOnMethods = "verifySymptomsPageTitle")
	public void verifyAppointmentScheduled() {
		patientHomePage = symptomsPage.submitSymptoms(Util.SYMPTOMS);
		Assert.assertTrue(patientHomePage.verifyAppointment(Util.DOCTOR, Util.APP_DAY, Util.APP_TIME, Util.SYMPTOMS),
				"Data Not Available");
	}

}
