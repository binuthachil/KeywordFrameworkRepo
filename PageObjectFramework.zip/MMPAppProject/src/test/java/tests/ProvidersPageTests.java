package tests;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBaseSetup;
import pageobjects.BasePage;
import pageobjects.PatientHomePage;
import pageobjects.ProvidersPage;
import pageobjects.ScheduleAppPage;
import pageobjects.SignInPage;
import utilities.Util;

public class ProvidersPageTests extends TestBaseSetup {
	private WebDriver driver;
	private BasePage basePage;
	private SignInPage signInPage;
	private PatientHomePage patientHomePage;
	private ScheduleAppPage scheduleAppPage;
	private ProvidersPage providersPage;
	
		
		@BeforeClass
		public void setUp() {
			driver=getDriver();
		}
		
		@Test
		public void verifyProvidersPage()
		{
			System.out.println("Schedule Appointment Page Tests");
			basePage = new BasePage(driver);
			signInPage = basePage.clickLoginBtn();
			patientHomePage=signInPage.signInFn(Util.PATIENT_UNAME, Util.PATIENT_PASSWORD);
			scheduleAppPage=patientHomePage.clkScheduleAppBtn();
			providersPage=scheduleAppPage.clkNewAppBtn();
			Assert.assertTrue(providersPage.verifyProviderPageTitle("Providers"), "Providers Page title doesn't match");
			
		}

}
