package tests;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.TestBaseSetup;
import pageobjects.BasePage;
import pageobjects.PatientHomePage;
import pageobjects.SignInPage;
import utilities.Util;

public class PatientHomePageTests extends TestBaseSetup {
	private WebDriver driver;
	private BasePage basePage;
	private SignInPage signInPage;
	private PatientHomePage patientHomePage;
	
		
		@BeforeClass
		public void setUp() {
			driver=getDriver();
		}
		
		@Test
		public void verifyPatientHomePage()
		{
			System.out.println("Patient Home Page Tests");
			basePage = new BasePage(driver);
			signInPage = basePage.clickLoginBtn();
			patientHomePage=signInPage.signInFn(Util.PATIENT_UNAME, Util.PATIENT_PASSWORD);
			Assert.assertTrue(patientHomePage.verifyHomePageTitle("home"), "Home Page title doesn't match");
		}

}