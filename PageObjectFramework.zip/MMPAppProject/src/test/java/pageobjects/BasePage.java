package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class BasePage {
	protected WebDriver driver;

	@FindBy(linkText = "Patient Login")
	private WebElement patientLoginMenu;
	@FindBy(linkText = "Login")
	private WebElement loginButton;

	public BasePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickPatientLoginMenu() {
		patientLoginMenu.click();

		// return new SignInPage(driver);
	}

	public SignInPage clickLoginBtn() {
		loginButton.click();
		return new SignInPage(driver);
	}

	public String getPageTitle() {
		String title = driver.getTitle();
		return title;
	}

	public boolean verifyBasePageTitle(String expectedTitle) {
		return getPageTitle().contains(expectedTitle);
	}
}