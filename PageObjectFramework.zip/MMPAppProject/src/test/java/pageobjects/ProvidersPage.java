package pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProvidersPage {

	private WebDriver driver;
	@FindBy(tagName = "table")
	private WebElement doctorTable;

	public ProvidersPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getPageTitle() {
		String title = driver.getTitle();
		return title;
	}

	public boolean verifyProviderPageTitle(String expectedTitle) {
		return getPageTitle().contains(expectedTitle);
	}

	public BookAppointmentFrame clickOnDoctor(String docName) {
		String doc;
		List<WebElement> rows = doctorTable.findElements(By.tagName("tr"));
		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			System.out.println("Number of columns:" + columns.size());
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				doc = columns.get(cnum).getText();
				System.out.println(doc);
				if (doc.toLowerCase().contains(docName)) {
					WebElement appBtn = columns.get(cnum).findElement(By.tagName("Button"));
					appBtn.click();
					driver.switchTo().frame("myframe");
					return new BookAppointmentFrame(driver);

				}

			}
		}
		return null;

	}

}
