package pageobjects;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import pageobjects.PatientHomePage;

public class SignInPage {

	private WebDriver driver;

	@FindBy(id = "h12")
	private WebElement loginHeaderText;
	@FindBy(id = "username")
	private WebElement userNameTextBox;
	@FindBy(id = "password")
	private WebElement passwordTextBox;
	@FindBy(name = "submit")
	private WebElement signinBtn;

	public SignInPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	private String getSignInPageTitle() {
		String pageTitle = driver.getTitle();
		return pageTitle;
	}

	public boolean verifySignInPageTitle(String expectedTitle) {
		return getSignInPageTitle().contains(expectedTitle);
	}

	public boolean verifySignInPageHeader(String expectedHeaderText) {
		String pageText = loginHeaderText.getText();
		return pageText.contains(expectedHeaderText);
	}

	private void enterUserName(String userName) {

		if (userNameTextBox.isDisplayed())
			userNameTextBox.sendKeys(userName);
	}

	private void enterPassword(String password) {

		if (passwordTextBox.isDisplayed())
			passwordTextBox.sendKeys(password);
	}

	public boolean verifySignIn(String uname, String pwd) {
		enterUserName(uname);
		enterPassword(pwd);
		signinBtn.click();
		try {
			Alert wrongLogin = driver.switchTo().alert();
			if (wrongLogin.getText().contains("Wrong")) {
				return false;
			}
		} catch (Exception e) {
			return true;
		}
		return true;
	}

	public PatientHomePage signInFn(String uname, String pwd) {
		enterUserName(uname);
		enterPassword(pwd);
		signinBtn.click();
		return new PatientHomePage(driver);

	}

}