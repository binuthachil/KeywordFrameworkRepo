package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ScheduleAppPage {

	private WebDriver driver;

	@FindBy(linkText = "Schedule Appointment")
	private WebElement scheduleAppBtn;
	@FindBy(xpath = "//div[3]/a/input")
	private WebElement newAppBtn;

	public ScheduleAppPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getPageTitle() {
		String title = driver.getTitle();
		return title;
	}

	public boolean verifySchedulePageTitle(String expectedTitle) {
		return getPageTitle().contains(expectedTitle);
	}

	public ScheduleAppPage clkSceduleAppBtn() {
		scheduleAppBtn.click();
		return new ScheduleAppPage(driver);
	}

	public ProvidersPage clkNewAppBtn() {
		newAppBtn.click();
		return new ProvidersPage(driver);
	}

}
