package pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class BookAppointmentFrame {

	private WebDriver driver;
	@FindBy(id = "datepicker")
	private WebElement datePickrTxt;

	@FindBy(id = "time")
	private WebElement timeSelect;

	@FindBy(id = "ui-id-2")
	private WebElement frameHeader;

	@FindBy(id = "ChangeHeatName")
	private WebElement continueBtn;

	@FindBy(id = "status")
	private WebElement appStatus;

	public BookAppointmentFrame(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public String getPageTitle() {
		String title = frameHeader.getText();
		return title;
	}

	public boolean verifyDateFrameTitle(String expectedTitle) {
		return getPageTitle().toLowerCase().contains(expectedTitle);
	}

	public void selectDate(String pDay) {
		datePickrTxt.click();
		String day;
		WebElement calendarTbl = driver.findElement(By.tagName("table"));
		List<WebElement> rows = calendarTbl.findElements(By.tagName("tr"));
		for (int rnum = 0; rnum < rows.size(); rnum++) {
			List<WebElement> columns = rows.get(rnum).findElements(By.tagName("td"));
			System.out.println("Number of columns:" + columns.size());
			for (int cnum = 0; cnum < columns.size(); cnum++) {
				day = columns.get(cnum).getText();
				System.out.println(day);
				if (day.contains(pDay)) {
					WebElement dayBtn = columns.get(cnum).findElement(By.tagName("a"));
					dayBtn.click();
					break;
				}

			}
		}
	}

	public void selectTime(String pTime) {

		Select timeList = new Select(timeSelect);
		timeList.selectByVisibleText(pTime);
	}

	public SymptomsPage scheduleAppointment(String day, String time) {

		selectDate(day);
		selectTime(time);
		clickOnContinue();
		return new SymptomsPage(driver);

	}

	public String verifyTimeAvailable(String day, String time) {

		selectDate(day);
		selectTime(time);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return appStatus.getText().trim();

	}

	public SymptomsPage clickOnContinue() {
		continueBtn.click();
		return new SymptomsPage(driver);
	}

}
